package com.example.demo_app.controller;

import com.example.demo_app.domain.stores.PlansStore;
import com.example.demo_app.domain.stores.SubscriptionsStore;
import com.example.demo_app.response.plan.PlanType;
import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.patterns.strategy.PricingStrategy;
import com.example.demo_app.patterns.strategy.PricingStrategyProvider;
import com.example.demo_app.request.NewMonthlyPriceRequest;
import com.example.demo_app.response.plan.PlanResponse;
import com.example.demo_app.response.plan.PlanWithPricesResponse;
import com.example.demo_app.response.subscriptions.Subscription;
import com.example.demo_app.response.subscriptions.SubscriptionStatus;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Controller
public class AdminController {
    private final PlansStore plansStore;
    private final SubscriptionsStore subscriptionsStore;

    public AdminController(PlansStore plansStore, SubscriptionsStore subscriptionsStore) {
        this.plansStore = plansStore;
        this.subscriptionsStore = subscriptionsStore;
    }


    @PostConstruct
    public void loadPlans() {
        try (
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(
                                getClass().getClassLoader().getResourceAsStream("data/plans.txt")
                        )
                )
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                Long id = Long.parseLong(parts[0]);
                PlanType type = PlanType.valueOf(parts[1]);
                String description = parts[2];
                double monthlyPrice = Double.parseDouble(parts[3]);
                int maxResolutions = Integer.parseInt(parts[4]);

                PlanResponse plan = new PlanResponse(id, type, description, monthlyPrice, maxResolutions);
                plansStore.addPlan(plan);
            }

            System.out.println("Plans loaded successfully.");

        } catch (Exception e) {
            throw new RuntimeException("Failed to load plans from file", e);
        }
    }

    @GetMapping("/admin")
    private String navigateToAdminPage() {
        return "admin/index";
    }

    @GetMapping("/admin/plans")
    private String navigateToPlansPage(Model model) {
        List<PlanWithPricesResponse> plansWithPrices =
                plansStore.getPlans().stream()
                        .map(plan -> {
                            PricingStrategy strategy =
                                    PricingStrategyProvider.getStrategy(plan.getType());

                            double monthly = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.ONE_MONTH);

                            double threeMonths = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.THREE_MONTHS);

                            double sixMonths = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.SIX_MONTHS);

                            double oneYear = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.ONE_YEAR);

                            return new PlanWithPricesResponse(
                                    plan.getId(),
                                    plan.getType().name(),
                                    plan.getDescription(),
                                    monthly,
                                    threeMonths,
                                    sixMonths,
                                    oneYear
                            );
                        })
                        .toList();

        model.addAttribute("plans", plansWithPrices);

        return "admin/plans/index";
    }

    @GetMapping("/admin/plans/{id}/editMonthlyPrice")
    private String navigateToEditMonthlyPricePlan(@PathVariable Long id, Model model){
        PlanResponse planResponse = plansStore.getPlans().stream().filter(p -> p.getId().equals(id)).findFirst().orElseThrow();
        model.addAttribute("plan", planResponse);
        model.addAttribute("newMonthlyPriceRequest", new NewMonthlyPriceRequest(planResponse.getId(),planResponse.getMonthlyPrice()));
        return "admin/plans/edit";
    }

    @GetMapping("/admin/subscriptions")
    private String navigateToSubscriptionsPage(Model model) {
        List<Subscription> subscriptions =
                new ArrayList<>(subscriptionsStore.getAll().values());

        double totalRevenue =
                subscriptions.stream()
                        .filter(sub -> sub.getStatus() == SubscriptionStatus.ACTIVE)
                        .mapToDouble(Subscription::getTotalPrice)
                        .sum();

        model.addAttribute("subscriptions", subscriptions);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("planTypes", PlanType.values());

        return "admin/subscriptions/index";
    }

    @PostMapping("/admin/plans/save")
    private String savePlanWithNewMonthlyPrice(@ModelAttribute NewMonthlyPriceRequest newMonthlyPriceRequest){
        if(newMonthlyPriceRequest.getId()!=null){
            PlanResponse planResponse = plansStore.getPlans().stream().filter(p -> p.getId().equals(newMonthlyPriceRequest.getId())).findFirst().orElseThrow();
            planResponse.setMonthlyPrice(newMonthlyPriceRequest.getPrice());
        }
        return "redirect:/admin/plans";
    }

    @GetMapping("/admin/subscriptions/filter")
    public String filterSubscriptions(
            @RequestParam PlanType planType,
            Model model
    ) {

        List<Subscription> filtered =
                subscriptionsStore.getAll().values().stream()
                        .filter(sub -> sub.getPlanType() == planType)
                        .toList();

        double totalRevenue =
                filtered.stream()
                        .filter(sub -> sub.getStatus() == SubscriptionStatus.ACTIVE)
                        .mapToDouble(Subscription::getTotalPrice)
                        .sum();

        model.addAttribute("subscriptions", filtered);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("planTypes", PlanType.values());
        model.addAttribute("selectedPlan", planType);

        return "admin/subscriptions/index";
    }

}
