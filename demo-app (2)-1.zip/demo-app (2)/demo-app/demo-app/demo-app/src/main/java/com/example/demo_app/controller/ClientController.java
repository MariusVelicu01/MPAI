package com.example.demo_app.controller;

import com.example.demo_app.domain.enums.Resolution;
import com.example.demo_app.domain.stores.MovieStore;
import com.example.demo_app.domain.stores.PlansStore;
import com.example.demo_app.domain.stores.SubscriptionsStore;
import com.example.demo_app.domain.stores.TicketStore;
import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.patterns.strategy.PricingStrategy;
import com.example.demo_app.patterns.strategy.PricingStrategyProvider;
import com.example.demo_app.request.ClientSubscriptionRequest;
import com.example.demo_app.request.TicketRequest;
import com.example.demo_app.response.clients.ClientResponse;
import com.example.demo_app.response.plan.PlanResponse;
import com.example.demo_app.response.plan.PlanType;
import com.example.demo_app.response.plan.PlanWithPricesResponse;
import com.example.demo_app.response.subscriptions.Subscription;
import com.example.demo_app.response.subscriptions.SubscriptionStatus;
import com.example.demo_app.response.subscriptions.abstract_factory.SubscriptionFactoryManager;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class ClientController {

    private List<ClientResponse> clients = new ArrayList<>();

    private final PlansStore plansStore;
    private final SubscriptionsStore subscriptionsStore;
    private final SubscriptionFactoryManager subscriptionFactoryManager;
    private final MovieStore movieStore;
    private final TicketStore ticketStore;

    public ClientController(PlansStore plansStore, SubscriptionsStore subscriptionsStore, SubscriptionFactoryManager subscriptionFactoryManager, MovieStore movieStore, TicketStore ticketStore) {
        this.plansStore = plansStore;
        this.subscriptionsStore = subscriptionsStore;
        this.subscriptionFactoryManager = subscriptionFactoryManager;
        this.movieStore = movieStore;
        this.ticketStore = ticketStore;
    }


    @PostConstruct
    private void init(){
        clients.add(new ClientResponse(1L,"Visan Andreea Florentina"));
        clients.add(new ClientResponse(2L,"Vieru Melisa"));
        clients.add(new ClientResponse(3L,"Vorniceanu Vlad"));
        clients.add(new ClientResponse(4L,"Velicu Marius Cristian"));
    }

    @GetMapping("/clients")
    private String navigateToClientsPage(Model model) {
        model.addAttribute("clients", clients);
        return "clients/index";
    }

    @GetMapping("/clients/{id}/details")
    private String navigateToClientPage(@PathVariable Long id, Model model) {
        ClientResponse clientResponse = clients.stream().filter(c -> c.getId().equals(id)).findFirst().orElseThrow();
        model.addAttribute("client", clientResponse);
        if (clientResponse.isHasSubscription()) {

            Subscription subscription =
                    subscriptionsStore.getByClientId(id);

            PlanResponse plan =
                    plansStore.getPlanByType(subscription.getPlanType());


            List<Resolution> allowedResolutions =
                    Arrays.stream(Resolution.values())
                            .limit(plan.getMaxResolutions())
                            .toList();

            model.addAttribute("movies", movieStore.getMovies());
            model.addAttribute("resolutions", allowedResolutions);

            model.addAttribute("subscription", subscription);

            if (clientResponse.isHasTickets()) {
                model.addAttribute(
                        "tickets",
                        ticketStore.getTicketsForClient(id)
                );
            }
        }

        return "clients/details";
    }

    @GetMapping("/clients/{id}/addSubscription")
    private String navigateToAddSubscriptionPage(@PathVariable Long id, Model model){
        ClientResponse clientResponse = clients.stream().filter(c -> c.getId().equals(id)).findFirst().orElseThrow();
        model.addAttribute("client", clientResponse);

        List<PlanWithPricesResponse> plansWithPrices =
                plansStore.getPlans().stream()
                        .map(plan -> {
                            PricingStrategy strategy =
                                    PricingStrategyProvider.getStrategy(plan.getType());

                            double monthly = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.ONE_MONTH);

                            double threeMonths = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.THREE_MONTHS);

                            double sixMonths = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.SIX_MONTHS);

                            double oneYear = strategy.calculatePrice(
                                    plan.getMonthlyPrice(), BillingPeriod.ONE_YEAR);

                            return new PlanWithPricesResponse(
                                    plan.getId(),
                                    plan.getType().name(),
                                    plan.getDescription(),
                                    monthly,
                                    threeMonths,
                                    sixMonths,
                                    oneYear
                            );
                        })
                        .toList();

        model.addAttribute("plans", plansWithPrices);
        model.addAttribute("clientRequest", new ClientSubscriptionRequest());
        model.addAttribute("planTypes", PlanType.values());
        model.addAttribute("billingPeriods", BillingPeriod.values());


        return "clients/addSubscription";
    }

    @PostMapping("/clients/{id}/saveSubscription")
    private String saveSubscription(@ModelAttribute ClientSubscriptionRequest clientSubscriptionRequest, @PathVariable Long id){
        ClientResponse clientResponse = clients.stream().filter(c -> c.getId().equals(id)).findFirst().orElseThrow();
        clientResponse.setHasSubscription(true);
        PlanResponse plan =
                plansStore.getPlanByType(clientSubscriptionRequest.getPlanType());

        Subscription subscription =
                subscriptionFactoryManager.createSubscription(
                        clientSubscriptionRequest.getPlanType(),
                        clientSubscriptionRequest.getBillingPeriod(),
                        plan.getMonthlyPrice()
                );

        subscriptionsStore.add(id, subscription);

        return "redirect:/clients/" + id + "/details";
    }

    @GetMapping("/clients/{id}/editSubscription")
    private String navigateToEditSubscriptionPage(
            @PathVariable Long id,
            Model model
    ) {
        ClientResponse client =
                clients.stream()
                        .filter(c -> c.getId().equals(id))
                        .findFirst()
                        .orElseThrow();

        Subscription subscription =
                subscriptionsStore.getByClientId(id);

        ClientSubscriptionRequest request =
                new ClientSubscriptionRequest();
        request.setPlanType(subscription.getPlanType());
        request.setBillingPeriod(subscription.getBillingPeriod());

        model.addAttribute("client", client);
        model.addAttribute("clientRequest", request);
        model.addAttribute("planTypes", PlanType.values());
        model.addAttribute("billingPeriods", BillingPeriod.values());
        model.addAttribute("editMode", true);

        subscriptionsStore.update(id, subscription);

        return "clients/addSubscription";
    }

    @GetMapping("/clients/{id}/cancelSubscription")
    private String cancelSubscription(@PathVariable Long id) {

        ClientResponse client =
                clients.stream()
                        .filter(c -> c.getId().equals(id))
                        .findFirst()
                        .orElseThrow();

        Subscription subscription =
                subscriptionsStore.getByClientId(id);

        subscription.setStatus(SubscriptionStatus.CANCELED);
        client.setHasSubscription(false);

        subscriptionsStore.update(id, subscription);

        return "redirect:/clients/" + id + "/details";
    }

    @GetMapping("/clients/{id}/addTicket")
    public String navigateToAddTicket(@PathVariable Long id, Model model) {

        ClientResponse client =
                clients.stream()
                        .filter(c -> c.getId().equals(id))
                        .findFirst()
                        .orElseThrow();

        model.addAttribute("client", client);
        model.addAttribute("ticketRequest", new TicketRequest());

        return "clients/addTicket";
    }

    @PostMapping("/clients/{id}/saveTicket")
    public String saveTicket(
            @PathVariable Long id,
            @ModelAttribute TicketRequest ticketRequest
    ) {
        ticketStore.create(id, ticketRequest);

        ClientResponse client =
                clients.stream()
                        .filter(c -> c.getId().equals(id))
                        .findFirst()
                        .orElseThrow();

        client.setHasTickets(true);



        return "redirect:/clients/" + id + "/details";
    }

}
