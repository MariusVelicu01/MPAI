package com.example.demo_app.controller;

import com.example.demo_app.domain.stores.TicketStore;
import com.example.demo_app.patterns.chain_of_responsability.L1SupportHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class L1SupportController {

    private final TicketStore ticketStore;
    private final L1SupportHandler handler;

    public L1SupportController(TicketStore ticketStore, L1SupportHandler handler) {
        this.ticketStore = ticketStore;
        this.handler = handler;
    }

    @GetMapping("/l1_support")
    public String view(Model model) {
        model.addAttribute("tickets", ticketStore.getForL1());
        return "support/l1";
    }

    @GetMapping("/l1_support/{id}/resolve")
    public String resolve(@PathVariable Long id) {
        handler.resolve(ticketStore.getById(id));
        return "redirect:/l1_support";
    }

    @GetMapping("/l1_support/{id}/escalate")
    public String escalate(@PathVariable Long id) {
        handler.escalate(ticketStore.getById(id));
        return "redirect:/l1_support";
    }
}
