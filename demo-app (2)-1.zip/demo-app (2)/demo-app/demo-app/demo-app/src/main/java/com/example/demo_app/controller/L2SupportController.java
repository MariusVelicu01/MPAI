package com.example.demo_app.controller;

import com.example.demo_app.domain.stores.TicketStore;
import com.example.demo_app.patterns.chain_of_responsability.L2SupportHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class L2SupportController {

    private final TicketStore ticketStore;
    private final L2SupportHandler handler;

    public L2SupportController(TicketStore ticketStore, L2SupportHandler handler) {
        this.ticketStore = ticketStore;
        this.handler = handler;
    }

    @GetMapping("/l2_support")
    public String view(Model model) {
        model.addAttribute("tickets", ticketStore.getForL2());
        return "support/l2";
    }

    @GetMapping("/l2_support/{id}/resolve")
    public String resolve(@PathVariable Long id) {
        handler.resolve(ticketStore.getById(id));
        return "redirect:/l2_support";
    }
}
