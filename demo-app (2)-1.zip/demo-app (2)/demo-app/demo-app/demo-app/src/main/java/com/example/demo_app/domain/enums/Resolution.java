package com.example.demo_app.domain.enums;

public enum Resolution {
    R360("360p"),
    R480("480p"),
    R720("720p"),
    R1080("1080p"),
    R2K("2K"),
    R4K("4K");

    private final String label;

    Resolution(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}