package com.example.demo_app.domain.stores;

import com.example.demo_app.domain.Movie;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class MovieStore {

    private final List<Movie> movies = new ArrayList<>();

    @PostConstruct
    public void init() {
        movies.add(new Movie(1, "Inception", "Mind-bending sci-fi thriller", 148));
        movies.add(new Movie(2, "Interstellar", "Space exploration and time", 169));
        movies.add(new Movie(3, "The Dark Knight", "Batman vs Joker", 152));
        movies.add(new Movie(4, "The Matrix", "Reality is an illusion", 136));
        movies.add(new Movie(5, "Fight Club", "Psychological drama", 139));
    }

    public List<Movie> getMovies() {
        return movies;
    }
}