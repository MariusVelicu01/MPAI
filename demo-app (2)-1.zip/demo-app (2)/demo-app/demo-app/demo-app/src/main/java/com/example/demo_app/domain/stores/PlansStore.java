package com.example.demo_app.domain.stores;

import com.example.demo_app.response.plan.PlanResponse;
import com.example.demo_app.response.plan.PlanType;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PlansStore {

    private final List<PlanResponse> plans = new ArrayList<>();

    public void addPlan(PlanResponse planResponse){
        plans.add(planResponse);
    }

    public List<PlanResponse> getPlans() {
        return plans;
    }

    public PlanResponse getPlanByType(PlanType type) {
        return plans.stream()
                .filter(plan -> plan.getType() == type)
                .findFirst()
                .orElseThrow(() ->
                        new IllegalArgumentException("Plan not found: " + type));
    }
}
