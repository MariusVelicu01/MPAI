package com.example.demo_app.domain.stores;

import com.example.demo_app.patterns.observer.SubscriptionObserver;
import com.example.demo_app.response.subscriptions.Subscription;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Component
public class SubscriptionsStore {

    private final Map<Long, Subscription> subscriptions = new HashMap<>();
    private final List<SubscriptionObserver> observers = new ArrayList<>();

    public void addObserver(SubscriptionObserver observer) {
        observers.add(observer);
    }

    private void notifyObservers(String event, Subscription subscription) {
        observers.forEach(o -> o.update(event, subscription));
    }

    public void add(Long clientId, Subscription subscription) {
        subscriptions.put(clientId, subscription);
        notifyObservers("SUBSCRIPTION_CREATED", subscription);
    }

    public void update(Long clientId, Subscription subscription) {
        subscriptions.put(clientId, subscription);
        notifyObservers("SUBSCRIPTION_UPDATED", subscription);
    }


    public Subscription getByClientId(Long clientId) {
        return subscriptions.get(clientId);
    }

    public Map<Long, Subscription> getAll() {
        return subscriptions;
    }
}
