package com.example.demo_app.domain.stores;

import com.example.demo_app.request.TicketRequest;
import com.example.demo_app.response.tickets.TicketResponse;
import com.example.demo_app.response.tickets.TicketStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class TicketStore {

    private final List<TicketResponse> tickets = new ArrayList<>();
    private long idCounter = 1;

    public TicketResponse create(Long clientId, TicketRequest request) {
        TicketResponse ticket =
                new TicketResponse(idCounter++, clientId, request.getProblemDescription());
        tickets.add(ticket);
        return ticket;
    }

    public List<TicketResponse> getTicketsForClient(Long clientId) {
        return tickets.stream()
                .filter(t -> t.getClientId().equals(clientId))
                .toList();
    }

    public List<TicketResponse> getForL1() {
        return tickets.stream()
                .filter(t -> t.getStatus() == TicketStatus.IN_PROGRESS_L1)
                .toList();
    }

    public List<TicketResponse> getForL2() {
        return tickets.stream()
                .filter(t -> t.getStatus() == TicketStatus.ESCALATED_L2)
                .toList();
    }

    public TicketResponse getById(Long id) {
        return tickets.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElseThrow();
    }

    public boolean clientHasTickets(Long clientId) {
        return tickets.stream().anyMatch(t -> t.getClientId().equals(clientId));
    }
}

