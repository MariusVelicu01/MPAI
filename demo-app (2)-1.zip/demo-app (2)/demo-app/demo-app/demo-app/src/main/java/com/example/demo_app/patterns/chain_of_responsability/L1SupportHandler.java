package com.example.demo_app.patterns.chain_of_responsability;

import com.example.demo_app.response.tickets.TicketResponse;
import com.example.demo_app.response.tickets.TicketStatus;
import org.springframework.stereotype.Component;

@Component
public class L1SupportHandler implements SupportHandler {

    private SupportHandler next;

    public void setNext(SupportHandler next) {
        this.next = next;
    }

    @Override
    public void resolve(TicketResponse ticket) {
        ticket.setStatus(TicketStatus.RESOLVED_L1);
    }

    @Override
    public void escalate(TicketResponse ticket) {
        ticket.setStatus(TicketStatus.ESCALATED_L2);
    }
}

