package com.example.demo_app.patterns.chain_of_responsability;

import com.example.demo_app.response.tickets.TicketResponse;
import com.example.demo_app.response.tickets.TicketStatus;
import org.springframework.stereotype.Component;

@Component
public class L2SupportHandler implements SupportHandler {

    @Override
    public void resolve(TicketResponse ticket) {
        ticket.setStatus(TicketStatus.RESOLVED_L2);
    }

    @Override
    public void escalate(TicketResponse ticket) {
        // L2 nu mai escaladează
    }
}