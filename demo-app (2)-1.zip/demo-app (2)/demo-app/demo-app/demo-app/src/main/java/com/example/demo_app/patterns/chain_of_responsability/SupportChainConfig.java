package com.example.demo_app.patterns.chain_of_responsability;

import org.springframework.stereotype.Component;

@Component
public class SupportChainConfig {

    public SupportChainConfig(L1SupportHandler l1, L2SupportHandler l2) {
        l1.setNext(l2);
    }
}
