package com.example.demo_app.patterns.chain_of_responsability;

import com.example.demo_app.response.tickets.TicketResponse;

public interface SupportHandler {
    void resolve(TicketResponse ticket);
    void escalate(TicketResponse ticket);
}
