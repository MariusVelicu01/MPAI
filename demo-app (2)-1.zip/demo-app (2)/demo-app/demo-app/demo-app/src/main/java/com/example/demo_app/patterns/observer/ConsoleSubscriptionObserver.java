package com.example.demo_app.patterns.observer;

import com.example.demo_app.response.subscriptions.Subscription;
import org.springframework.stereotype.Component;

@Component
public class ConsoleSubscriptionObserver implements SubscriptionObserver {

    @Override
    public void update(String event, Subscription subscription) {
        System.out.println(
                "[SUBSCRIPTION EVENT] " + event +
                        " | PLAN=" + subscription.getPlanType() +
                        " | PERIOD=" + subscription.getBillingPeriod() +
                        " | STATUS=" + subscription.getStatus() +
                        " | PRICE=" + subscription.getTotalPrice()
        );
    }

}