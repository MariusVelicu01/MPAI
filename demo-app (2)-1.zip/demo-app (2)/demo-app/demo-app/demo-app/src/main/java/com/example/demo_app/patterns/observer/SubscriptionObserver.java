package com.example.demo_app.patterns.observer;

import com.example.demo_app.response.subscriptions.Subscription;

public interface SubscriptionObserver {
    void update(String event, Subscription subscription);
}