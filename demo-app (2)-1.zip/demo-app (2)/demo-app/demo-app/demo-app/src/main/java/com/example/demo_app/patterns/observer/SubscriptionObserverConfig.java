package com.example.demo_app.patterns.observer;

import com.example.demo_app.domain.stores.SubscriptionsStore;
import org.springframework.stereotype.Component;

@Component
public class SubscriptionObserverConfig {

    public SubscriptionObserverConfig(
            SubscriptionsStore store,
            ConsoleSubscriptionObserver consoleObserver
    ) {
        store.addObserver(consoleObserver);
    }
}