package com.example.demo_app.patterns.strategy;

public class BasicPricingStrategy implements PricingStrategy {

    @Override
    public double calculatePrice(double monthlyPrice, BillingPeriod period) {
        double basePrice = monthlyPrice * period.getMonths();

        return switch (period) {
            case ONE_MONTH -> basePrice;
            case THREE_MONTHS -> basePrice * 0.95;
            case SIX_MONTHS -> basePrice * 0.90;
            case ONE_YEAR -> basePrice * 0.85;
        };
    }
}