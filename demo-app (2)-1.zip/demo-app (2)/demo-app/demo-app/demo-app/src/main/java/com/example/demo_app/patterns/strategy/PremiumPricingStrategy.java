package com.example.demo_app.patterns.strategy;

public class PremiumPricingStrategy implements PricingStrategy {

    @Override
    public double calculatePrice(double monthlyPrice, BillingPeriod period) {
        double basePrice = monthlyPrice * period.getMonths();

        return switch (period) {
            case ONE_MONTH -> basePrice;
            case THREE_MONTHS -> basePrice * 0.93;
            case SIX_MONTHS -> basePrice * 0.85;
            case ONE_YEAR -> basePrice * 0.82;
        };
    }
}
