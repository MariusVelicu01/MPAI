package com.example.demo_app.patterns.strategy;

public interface PricingStrategy {
    double calculatePrice(double monthlyPrice, BillingPeriod period);
}
