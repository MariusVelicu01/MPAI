package com.example.demo_app.patterns.strategy;

import com.example.demo_app.response.plan.PlanType;

public class PricingStrategyProvider {
    public static PricingStrategy getStrategy(PlanType planType) {
        return switch (planType) {
            case BASIC -> new BasicPricingStrategy();
            case PREMIUM -> new PremiumPricingStrategy();
            case VIP -> new VipPricingStrategy();
        };
    }

}