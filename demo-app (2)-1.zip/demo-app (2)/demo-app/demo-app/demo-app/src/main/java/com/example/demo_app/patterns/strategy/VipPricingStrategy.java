package com.example.demo_app.patterns.strategy;

public class VipPricingStrategy implements PricingStrategy {
    @Override
    public double calculatePrice(double monthlyPrice, BillingPeriod period) {
        double basePrice = monthlyPrice * period.getMonths();

        return switch (period) {
            case ONE_MONTH -> basePrice;
            case THREE_MONTHS -> basePrice * 0.90;
            case SIX_MONTHS -> basePrice * 0.82;
            case ONE_YEAR -> basePrice * 0.78;
        };
    }
}