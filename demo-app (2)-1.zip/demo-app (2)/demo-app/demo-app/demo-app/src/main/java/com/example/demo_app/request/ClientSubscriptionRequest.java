package com.example.demo_app.request;

import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.response.plan.PlanType;

public class ClientSubscriptionRequest {
    private Long id;
    private PlanType planType;
    private BillingPeriod billingPeriod;

    public ClientSubscriptionRequest() {
    }

    public ClientSubscriptionRequest(Long id, PlanType planType, BillingPeriod billingPeriod) {
        this.id = id;
        this.planType = planType;
        this.billingPeriod = billingPeriod;
    }

    public ClientSubscriptionRequest(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PlanType getPlanType() {
        return planType;
    }

    public void setPlanType(PlanType planType) {
        this.planType = planType;
    }

    public BillingPeriod getBillingPeriod() {
        return billingPeriod;
    }

    public void setBillingPeriod(BillingPeriod billingPeriod) {
        this.billingPeriod = billingPeriod;
    }

    @Override
    public String toString() {
        return "ClientSubscriptionRequest{" +
                "id=" + id +
                ", planType='" + planType + '\'' +
                ", billingPeriod='" + billingPeriod + '\'' +
                '}';
    }
}
