package com.example.demo_app.request;

public class NewMonthlyPriceRequest {
    private Long id;
    private double price;

    public NewMonthlyPriceRequest() {
    }

    public NewMonthlyPriceRequest(Long id, double price) {
        this.id = id;
        this.price = price;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "NewMonthlyPriceRequest{" +
                "id=" + id +
                ", price=" + price +
                '}';
    }
}
