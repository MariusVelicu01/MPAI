package com.example.demo_app.request;

import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.response.plan.PlanType;

public class SubscriptionRequest {
    private PlanType planType;
    private BillingPeriod billingPeriod;

    public SubscriptionRequest(PlanType planType, BillingPeriod billingPeriod) {
        this.planType = planType;
        this.billingPeriod = billingPeriod;
    }

    public PlanType getPlanType() {
        return planType;
    }

    public void setPlanType(PlanType planType) {
        this.planType = planType;
    }

    public BillingPeriod getBillingPeriod() {
        return billingPeriod;
    }

    public void setBillingPeriod(BillingPeriod billingPeriod) {
        this.billingPeriod = billingPeriod;
    }

    @Override
    public String toString() {
        return "SubscriptionRequest{" +
                "planType=" + planType +
                ", billingPeriod=" + billingPeriod +
                '}';
    }
}
