package com.example.demo_app.request;

public class TicketRequest {

    private String problemDescription;

    public String getProblemDescription() {
        return problemDescription;
    }

    public void setProblemDescription(String problemDescription) {
        this.problemDescription = problemDescription;
    }
}