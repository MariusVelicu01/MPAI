package com.example.demo_app.response.clients;

public class ClientResponse {
    private Long id;
    private String name;
    private boolean hasSubscription;
    private boolean hasTickets;

    public ClientResponse() {
    }

    public ClientResponse(Long id, String name, boolean hasSubscription) {
        this.id = id;
        this.name = name;
        this.hasSubscription = hasSubscription;
    }

    public ClientResponse(Long id, String name) {
        this.id = id;
        this.name = name;
        this.hasSubscription = false;
        this.hasTickets = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isHasSubscription() {
        return hasSubscription;
    }

    public void setHasSubscription(boolean hasSubscription) {
        this.hasSubscription = hasSubscription;
    }

    public boolean isHasTickets() {
        return hasTickets;
    }

    public void setHasTickets(boolean hasTickets) {
        this.hasTickets = hasTickets;
    }

    @Override
    public String toString() {
        return "ClientResponse{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", hasSubscription=" + hasSubscription +
                ", hasTickets=" + hasTickets +
                '}';
    }
}
