package com.example.demo_app.response.plan;

public enum BillingCycle {
    MONTHLY,
    YEARLY
}
