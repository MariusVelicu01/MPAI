package com.example.demo_app.response.plan;

public class PlanResponse {
    private Long id;
    private PlanType type;
    private String description;
    private double monthlyPrice;
    private int maxResolutions;

    public PlanResponse() {
    }

    public PlanResponse(Long id, PlanType type, String description, double monthlyPrice, int maxResolutions) {
        this.id = id;
        this.type = type;
        this.description = description;
        this.monthlyPrice = monthlyPrice;
        this.maxResolutions = maxResolutions;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PlanType getType() {
        return type;
    }

    public void setType(PlanType type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getMonthlyPrice() {
        return monthlyPrice;
    }

    public void setMonthlyPrice(double monthlyPrice) {
        if(monthlyPrice<=0){
            System.out.println("The price cannot be less than 0!");
        } else {
            this.monthlyPrice = monthlyPrice;
        }
    }

    public int getMaxResolutions() {
        return maxResolutions;
    }

    public void setMaxResolutions(int maxResolutions) {
        this.maxResolutions = maxResolutions;
    }

    @Override
    public String toString() {
        return "PlanResponse{" +
                "id=" + id +
                ", type=" + type +
                ", description='" + description + '\'' +
                ", monthlyPrice=" + monthlyPrice +
                ", maxResolutions=" + maxResolutions +
                '}';
    }
}
