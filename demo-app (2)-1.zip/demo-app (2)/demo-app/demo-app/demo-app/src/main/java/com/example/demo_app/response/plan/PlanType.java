package com.example.demo_app.response.plan;

public enum PlanType {
    BASIC,
    PREMIUM,
    VIP
}
