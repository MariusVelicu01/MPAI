package com.example.demo_app.response.plan;

public class PlanWithPricesResponse {
    private Long id;
    private String name;
    private String description;

    private double monthlyPrice;
    private double price3Months;
    private double price6Months;
    private double price1Year;

    public PlanWithPricesResponse() {
    }

    public PlanWithPricesResponse(Long id, String name, String description, double monthlyPrice, double price3Months, double price6Months, double price1Year) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.monthlyPrice = monthlyPrice;
        this.price3Months = price3Months;
        this.price6Months = price6Months;
        this.price1Year = price1Year;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getMonthlyPrice() {
        return monthlyPrice;
    }

    public void setMonthlyPrice(double monthlyPrice) {
        this.monthlyPrice = monthlyPrice;
    }

    public double getPrice3Months() {
        return price3Months;
    }

    public void setPrice3Months(double price3Months) {
        this.price3Months = price3Months;
    }

    public double getPrice6Months() {
        return price6Months;
    }

    public void setPrice6Months(double price6Months) {
        this.price6Months = price6Months;
    }

    public double getPrice1Year() {
        return price1Year;
    }

    public void setPrice1Year(double price1Year) {
        this.price1Year = price1Year;
    }

    @Override
    public String toString() {
        return "PlanWithPricingResponse{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", monthlyPrice=" + monthlyPrice +
                ", price3Months=" + price3Months +
                ", price6Months=" + price6Months +
                ", price1Year=" + price1Year +
                '}';
    }
}
