package com.example.demo_app.response.plan;

public class PricingPerPeriodResponse {
    private double monthlyPrice;
    private double price3Months;
    private double price6Months;
    private double price1Year;

    public PricingPerPeriodResponse() {
    }

    public PricingPerPeriodResponse(double monthlyPrice, double price3Months, double price6Months, double price1Year) {
        this.monthlyPrice = monthlyPrice;
        this.price3Months = price3Months;
        this.price6Months = price6Months;
        this.price1Year = price1Year;
    }

    public double getMonthlyPrice() {
        return monthlyPrice;
    }

    public void setMonthlyPrice(double monthlyPrice) {
        this.monthlyPrice = monthlyPrice;
    }

    public double getPrice3Months() {
        return price3Months;
    }

    public void setPrice3Months(double price3Months) {
        this.price3Months = price3Months;
    }

    public double getPrice6Months() {
        return price6Months;
    }

    public void setPrice6Months(double price6Months) {
        this.price6Months = price6Months;
    }

    public double getPrice1Year() {
        return price1Year;
    }

    public void setPrice1Year(double price1Year) {
        this.price1Year = price1Year;
    }

    @Override
    public String toString() {
        return "PricingPerPeriodResponse{" +
                "monthlyPrice=" + monthlyPrice +
                ", price3Months=" + price3Months +
                ", price6Months=" + price6Months +
                ", price1Year=" + price1Year +
                '}';
    }
}
