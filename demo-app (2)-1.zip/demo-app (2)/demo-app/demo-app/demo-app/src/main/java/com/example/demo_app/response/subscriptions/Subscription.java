package com.example.demo_app.response.subscriptions;

import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.response.plan.PlanType;

public interface Subscription {

    PlanType getPlanType();

    BillingPeriod getBillingPeriod();

    double getTotalPrice();

    SubscriptionStatus getStatus();
    void setStatus(SubscriptionStatus status);
}
