package com.example.demo_app.response.subscriptions;

import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.response.plan.PlanType;

public class SubscriptionResponse {
    private Long id;
    private PlanType planType;
    private BillingPeriod billingPeriod;
    private double totalPrice;
    private SubscriptionStatus status;
    private Long idClient;
    private static Long idCounter = 1L;

    public SubscriptionResponse(PlanType planType, BillingPeriod billingPeriod, double totalPrice, SubscriptionStatus status) {
        this.id = idCounter++;
        this.planType = planType;
        this.billingPeriod = billingPeriod;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PlanType getPlanType() {
        return planType;
    }

    public void setPlanType(PlanType planType) {
        this.planType = planType;
    }

    public BillingPeriod getBillingPeriod() {
        return billingPeriod;
    }

    public void setBillingPeriod(BillingPeriod billingPeriod) {
        this.billingPeriod = billingPeriod;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public SubscriptionStatus getStatus() {
        return status;
    }

    public void setStatus(SubscriptionStatus status) {
        this.status = status;
    }

    public Long getIdClient() {
        return idClient;
    }

    public void setIdClient(Long idClient) {
        this.idClient = idClient;
    }

    public static Long getIdCounter() {
        return idCounter;
    }

    public static void setIdCounter(Long idCounter) {
        SubscriptionResponse.idCounter = idCounter;
    }

    @Override
    public String toString() {
        return "SubscriptionResponse{" +
                "id=" + id +
                ", planType=" + planType +
                ", billingPeriod=" + billingPeriod +
                ", totalPrice=" + totalPrice +
                ", status=" + status +
                ", idClient=" + idClient +
                '}';
    }
}
