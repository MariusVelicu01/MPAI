package com.example.demo_app.response.subscriptions;

public enum SubscriptionStatus {
    ACTIVE,
    CANCELED
}
