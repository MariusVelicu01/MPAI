package com.example.demo_app.response.subscriptions;

import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.response.plan.PlanType;

public class VipSubscription implements Subscription {

    private final BillingPeriod billingPeriod;
    private final double totalPrice;
    private SubscriptionStatus status = SubscriptionStatus.ACTIVE;

    public VipSubscription(BillingPeriod billingPeriod, double totalPrice) {
        this.billingPeriod = billingPeriod;
        this.totalPrice = totalPrice;
    }

    @Override
    public PlanType getPlanType() {
        return PlanType.VIP;
    }

    @Override
    public BillingPeriod getBillingPeriod() {
        return billingPeriod;
    }

    @Override
    public double getTotalPrice() {
        return totalPrice;
    }

    @Override
    public SubscriptionStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(SubscriptionStatus status) {
        this.status = status;
    }
}