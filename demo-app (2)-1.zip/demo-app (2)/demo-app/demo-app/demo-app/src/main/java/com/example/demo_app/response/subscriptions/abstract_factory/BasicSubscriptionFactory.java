package com.example.demo_app.response.subscriptions.abstract_factory;

import com.example.demo_app.patterns.strategy.BasicPricingStrategy;
import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.patterns.strategy.PricingStrategy;
import com.example.demo_app.request.SubscriptionRequest;
import com.example.demo_app.response.plan.PlanType;
import com.example.demo_app.response.subscriptions.BasicSubscription;
import com.example.demo_app.response.subscriptions.Subscription;
import com.example.demo_app.response.subscriptions.SubscriptionResponse;
import com.example.demo_app.response.subscriptions.SubscriptionStatus;

public class BasicSubscriptionFactory implements SubscriptionFactory {

    private final PricingStrategy strategy = new BasicPricingStrategy();

    @Override
    public Subscription create(BillingPeriod billingPeriod, double monthlyPrice) {
        double price = strategy.calculatePrice(monthlyPrice, billingPeriod);
        return new BasicSubscription(billingPeriod, price);
    }
}