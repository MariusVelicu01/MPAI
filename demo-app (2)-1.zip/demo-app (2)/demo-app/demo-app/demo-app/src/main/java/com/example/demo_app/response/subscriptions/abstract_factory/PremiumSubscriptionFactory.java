package com.example.demo_app.response.subscriptions.abstract_factory;

import com.example.demo_app.patterns.strategy.BasicPricingStrategy;
import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.patterns.strategy.PremiumPricingStrategy;
import com.example.demo_app.patterns.strategy.PricingStrategy;
import com.example.demo_app.request.SubscriptionRequest;
import com.example.demo_app.response.plan.PlanType;
import com.example.demo_app.response.subscriptions.*;

public class PremiumSubscriptionFactory implements SubscriptionFactory {

    private final PricingStrategy strategy = new PremiumPricingStrategy();

    @Override
    public Subscription create(BillingPeriod billingPeriod, double monthlyPrice) {
        double price = strategy.calculatePrice(monthlyPrice, billingPeriod);
        return new PremiumSubscription(billingPeriod, price);
    }
}