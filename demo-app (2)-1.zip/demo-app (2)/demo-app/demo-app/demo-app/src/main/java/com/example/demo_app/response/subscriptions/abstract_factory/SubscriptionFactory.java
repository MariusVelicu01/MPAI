package com.example.demo_app.response.subscriptions.abstract_factory;

import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.request.SubscriptionRequest;
import com.example.demo_app.response.subscriptions.Subscription;
import com.example.demo_app.response.subscriptions.SubscriptionResponse;

public interface SubscriptionFactory {

    Subscription create(BillingPeriod billingPeriod, double monthlyPrice);
}