package com.example.demo_app.response.subscriptions.abstract_factory;

import com.example.demo_app.patterns.strategy.BillingPeriod;
import com.example.demo_app.response.plan.PlanType;
import com.example.demo_app.response.subscriptions.Subscription;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.Map;
@Component
public class SubscriptionFactoryManager {
    private final Map<PlanType, SubscriptionFactory> factories =
            new EnumMap<>(PlanType.class);

    public SubscriptionFactoryManager() {
        factories.put(PlanType.BASIC, new BasicSubscriptionFactory());
        factories.put(PlanType.PREMIUM, new PremiumSubscriptionFactory());
        factories.put(PlanType.VIP, new VipSubscriptionFactory());
    }

    public Subscription createSubscription(
            PlanType planType,
            BillingPeriod billingPeriod,
            double monthlyPrice
    ) {
        SubscriptionFactory factory = factories.get(planType);

        if (factory == null) {
            throw new IllegalArgumentException("Unsupported plan type");
        }

        return factory.create(billingPeriod, monthlyPrice);
    }
}
