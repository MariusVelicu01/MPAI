package com.example.demo_app.response.tickets;

public class TicketResponse {

    private Long id;
    private Long clientId;
    private String problemDescription;
    private TicketStatus status;

    public TicketResponse(Long id, Long clientId, String problemDescription) {
        this.id = id;
        this.clientId = clientId;
        this.problemDescription = problemDescription;
        this.status = TicketStatus.IN_PROGRESS_L1;
    }

    public Long getId() { return id; }
    public Long getClientId() { return clientId; }
    public String getProblemDescription() { return problemDescription; }
    public TicketStatus getStatus() { return status; }
    public void setStatus(TicketStatus status) { this.status = status; }
}