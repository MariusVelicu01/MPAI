package com.example.demo_app.response.tickets;

public enum TicketStatus {
    IN_PROGRESS_L1,
    RESOLVED_L1,
    ESCALATED_L2,
    RESOLVED_L2
}