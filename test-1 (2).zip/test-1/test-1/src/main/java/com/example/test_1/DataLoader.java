package com.example.test_1;

import com.example.test_1.entities.TestEntity;
import com.example.test_1.repository.TestRepository;
import org.springframework.stereotype.Component;

@Component
public class DataLoader {

    public DataLoader(TestRepository repo) {
        repo.save(new TestEntity("H2 works"));
    }
}