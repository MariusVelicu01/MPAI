package com.example.test_1.controller;

import com.example.test_1.entities.Client;
import com.example.test_1.entities.OrderEntity;
import com.example.test_1.entities.Product;
import com.example.test_1.enums.OrderStatus;
import com.example.test_1.repository.ClientRepository;
import com.example.test_1.repository.OrderRepository;
import com.example.test_1.repository.ProductRepository;
import com.example.test_1.request.OrderRequest;
import com.example.test_1.response.ClientResponse;
import com.example.test_1.response.OrderResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class ClientController {
    private final ClientRepository clientRepository;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;

    public ClientController(ClientRepository clientRepository, ProductRepository productRepository, OrderRepository orderRepository) {
        this.clientRepository = clientRepository;
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
    }

    @GetMapping("/clients")
    private String navigateToClientsPage(Model model){
        model.addAttribute("clients", clientRepository.findAll());
        return "clients/index";
    }

    @GetMapping("/clients/{id}/orders")
    private String navigateToClientsOrdersPage(@PathVariable Long id, Model model){
        Client client = clientRepository.findAll().stream().filter(c -> c.getId().equals(id)).findFirst().orElseThrow();
        model.addAttribute("client", new ClientResponse(client.getId(), client.getName(), client.isHasOrders()));
        if(client.isHasOrders()==true){
            List<OrderResponse> orderResponses = orderRepository.findAll().stream().filter(o -> o.getIdClient().equals(id)).map(
                    o -> new OrderResponse(o.getId(),
                            productRepository.findAll().stream().filter(p-> p.getId().equals(o.getProductId())).findFirst().orElseThrow().getName(),
                            o.getQuantity(),
                            productRepository.findAll().stream().filter(p-> p.getId().equals(o.getProductId())).findFirst().orElseThrow().getPrice(),
                            o.getOrderDate(),
                            o.getOrderStatus()
                    )
            ).toList();
            model.addAttribute("OrderStatus", OrderStatus.class);
            model.addAttribute("orders", orderResponses);
        }
        return "clients/orders";
    }

    @GetMapping("/clients/{id}/addOrder")
    private String navigateToClientAddOrderPage(@PathVariable Long id, Model model){
        Client client = clientRepository.findAll().stream().filter(c -> c.getId().equals(id)).findFirst().orElseThrow();
        model.addAttribute("client", new ClientResponse(client.getId(), client.getName(), client.isHasOrders()));
        model.addAttribute("order", new OrderRequest());
        model.addAttribute("products", productRepository.findAll());
        System.out.println(productRepository.findAll());
        System.out.println(clientRepository.findAll());
        return "clients/addOrder";
    }

    @PostMapping("/client/{id}/saveOrder")
    private String saveOrder(@PathVariable Long id, @ModelAttribute OrderRequest orderRequest){
        Optional<Product> optionalProduct = productRepository.findAll().stream().filter(p -> p.getName().equals(orderRequest.getProductName())).findFirst();
        if(optionalProduct.get().getStock()<orderRequest.getQuantity() || optionalProduct.isEmpty()){
            System.out.println("This order cannot be placed!");
        } else {
            Product product = optionalProduct.get();
            product.setStock(product.getStock() - orderRequest.getQuantity());
            OrderEntity order = new OrderEntity(product.getId(), orderRequest.getQuantity(), id);
            orderRepository.save(order);
            Client client = clientRepository.findAll().stream().filter(c -> c.getId().equals(id)).findFirst().orElseThrow();
            client.setHasOrders(true);
            clientRepository.save(client);
        }
        return "redirect:/clients/"+id+"/orders";
    }

    @PostMapping("/orders/{orderId}/cancel")
    public String cancelOrder(@PathVariable Long orderId) {

        OrderEntity order = orderRepository.findById(orderId)
                .orElseThrow();

        order.setOrderStatus(OrderStatus.ANULATA);
        orderRepository.save(order);

        return "redirect:/clients/" + order.getIdClient() + "/orders";
    }
}
