package com.example.test_1.dataLoader;

import com.example.test_1.entities.Client;
import com.example.test_1.repository.ClientRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

@Component
public class DataLoaderClient {
    private final ClientRepository clientRepository;

    public DataLoaderClient(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
        loadData();
    }

    private void loadData() {
        try {
            InputStream is = getClass()
                    .getClassLoader()
                    .getResourceAsStream("IN/clients.txt");

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is)
            );

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");

                Client client = new Client(
                        values[0].trim()
                );

                clientRepository.save(client);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
