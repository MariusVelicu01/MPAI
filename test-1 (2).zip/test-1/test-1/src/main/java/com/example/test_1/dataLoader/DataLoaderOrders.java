package com.example.test_1.dataLoader;

import com.example.test_1.entities.OrderEntity;
import com.example.test_1.repository.OrderRepository;
import org.springframework.stereotype.Component;

@Component
public class DataLoaderOrders {
    private final OrderRepository orderRepository;

    public DataLoaderOrders(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public void saveOrder(OrderEntity order){
        orderRepository.save(order);
    }
}
