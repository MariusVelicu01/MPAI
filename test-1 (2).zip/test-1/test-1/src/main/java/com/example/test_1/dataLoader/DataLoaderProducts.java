package com.example.test_1.dataLoader;

import com.example.test_1.entities.Client;
import com.example.test_1.entities.Product;
import com.example.test_1.repository.ProductRepository;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
@Component
public class DataLoaderProducts {
    private final ProductRepository productRepository;

    public DataLoaderProducts(ProductRepository productRepository) {
        this.productRepository = productRepository;
        loadData();
    }

    private void loadData() {
        try {
            InputStream is = getClass()
                    .getClassLoader()
                    .getResourceAsStream("IN/products.txt");

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is)
            );

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");

                Product product = new Product(
                        values[0].trim(),
                        Double.parseDouble(values[1].trim()),
                        Integer.parseInt(values[2].trim())
                );

                System.out.println(product.toString());

                productRepository.save(product);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
