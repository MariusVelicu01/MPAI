package com.example.test_1.entities;

import com.example.test_1.enums.OrderStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.time.LocalDate;

@Entity
public class OrderEntity {
    @Id
    @GeneratedValue
    private Long id;
    private Long productId;
    private int quantity;
    private Long idClient;
    private LocalDate orderDate;
    private OrderStatus orderStatus;

    public OrderEntity() {
    }

    public OrderEntity(Long productId, int quantity, Long idClient) {
        this.productId = productId;
        this.quantity = quantity;
        this.idClient = idClient;
        this.orderDate = LocalDate.now();
        this.orderStatus = OrderStatus.PLASATA;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Long getIdClient() {
        return idClient;
    }

    public void setIdClient(Long idClient) {
        this.idClient = idClient;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }
}
