package com.example.test_1.enums;

public enum OrderStatus {
    PLASATA,
    PROCESATA,
    EXPEDIATA,
    LIVRATA,
    ANULATA
}
