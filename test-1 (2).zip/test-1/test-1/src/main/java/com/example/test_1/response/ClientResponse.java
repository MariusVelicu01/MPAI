package com.example.test_1.response;

public class ClientResponse {
    private Long id;
    private String name;
    private boolean hasOrders;

    public ClientResponse() {
    }

    public ClientResponse(Long id, String name, boolean hasOrders) {
        this.id = id;
        this.name = name;
        this.hasOrders = hasOrders;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isHasOrders() {
        return hasOrders;
    }

    public void setHasOrders(boolean hasOrders) {
        this.hasOrders = hasOrders;
    }

    @Override
    public String toString() {
        return "ClientResponse{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", hasOrders=" + hasOrders +
                '}';
    }
}
