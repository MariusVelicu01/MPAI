package com.example.test_1.response;

import com.example.test_1.enums.OrderStatus;

import java.time.LocalDate;

public class OrderResponse {
    private Long id;
    private String productName;
    private int quantity;
    private double productPrice;
    private LocalDate orderDate;
    private OrderStatus orderStatus;

    public OrderResponse() {
    }

    public OrderResponse(Long id, String productName, int quantity, double productPrice, LocalDate orderDate, OrderStatus orderStatus) {
        this.id = id;
        this.productName = productName;
        this.quantity = quantity;
        this.productPrice = productPrice;
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public double getTotalOrderPrice(){
        return this.quantity*this.productPrice;
    }
}
